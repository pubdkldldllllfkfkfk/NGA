# بناء APK

## الطريقة 1: GitHub Actions (بدون كمبيوتر)
1. أنشئ مستودعًا جديدًا على GitHub وارفع محتوى هذا المجلد (وليس الـ zip نفسه).
2. افتح تبويب **Actions** ثم **Build APK (no secrets needed)** ثم **Run workflow**.
3. بعد انتهاء البناء افتح التشغيل ونزّل **Canta-apk** (ملف zip فيه الـ APK).

## الطريقة 2: على كمبيوتر
المتطلبات: JDK 21 وAndroid SDK (compileSdk 37).
    ./gradlew :androidApp:assembleDebug
الناتج: androidApp/build/outputs/apk/debug/

## ملاحظات
- الـ APK موقّع بمفتاح debug، فإن كان Canta الأصلي مثبّتًا بتوقيع مختلف فعليك حذفه أولًا.
- لم يُجرَّب البناء في بيئة التطوير التي عُدّل فيها المشروع.
- لم يُدمج Shizuku بعد (ينقص Shizuku-API).
