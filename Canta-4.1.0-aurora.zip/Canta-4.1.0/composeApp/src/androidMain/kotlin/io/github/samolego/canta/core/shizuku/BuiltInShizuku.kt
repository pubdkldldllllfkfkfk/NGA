package io.github.samolego.canta.core.shizuku

import android.content.Context

/** Whether Canta uses its built-in Shizuku service instead of the Shizuku app. */
object BuiltInShizuku {
    private const val PREFS = "built_in_shizuku"
    private const val KEY_ENABLED = "enabled"

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }
}
