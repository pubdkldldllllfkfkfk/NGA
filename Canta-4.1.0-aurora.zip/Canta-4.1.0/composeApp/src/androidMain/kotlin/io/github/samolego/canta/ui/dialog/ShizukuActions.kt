package io.github.samolego.canta.ui.dialog

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import io.github.samolego.canta.util.LogUtils
import moe.shizuku.manager.adb.AdbPairingService

private const val TAG = "ShizukuActions"

/** Starts the notification-based pairing. Returns true when the pairing notification was started. */
internal fun startNotificationPairing(context: Context): Boolean {
    val activity = generateSequence(context) { (it as? ContextWrapper)?.baseContext }
        .filterIsInstance<Activity>().firstOrNull()
    val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    if (needsPermission && activity != null) {
        activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        return false
    }
    return try {
        context.startForegroundService(AdbPairingService.startIntent(context))
        true
    } catch (e: Throwable) {
        LogUtils.e(TAG, "Could not start the pairing service", e)
        false
    }
}

internal fun openDeveloperOptions(context: Context) {
    try {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        LogUtils.e(TAG, "Failed to open developer options", e)
    }
}

internal fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        LogUtils.e(TAG, "Failed to open $url", e)
    }
}
