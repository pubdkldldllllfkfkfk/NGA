package io.github.samolego.canta.ui.screen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.text.Html
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Adb
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import io.github.samolego.canta.generated.resources.builtin_boot
import io.github.samolego.canta.generated.resources.builtin_boot_perm_missing
import io.github.samolego.canta.generated.resources.builtin_boot_perm_ok
import io.github.samolego.canta.generated.resources.builtin_boot_summary
import io.github.samolego.canta.generated.resources.builtin_copy_grant
import io.github.samolego.canta.generated.resources.builtin_notification_sent
import io.github.samolego.canta.generated.resources.builtin_open_dev_options
import io.github.samolego.canta.generated.resources.builtin_pair_notification
import io.github.samolego.canta.generated.resources.builtin_show_log
import io.github.samolego.canta.generated.resources.builtin_stop
import io.github.samolego.canta.generated.resources.builtin_start
import io.github.samolego.canta.generated.resources.Res
import io.github.samolego.canta.generated.resources.shizuku_apps_need_service
import io.github.samolego.canta.generated.resources.shizuku_last_log
import io.github.samolego.canta.generated.resources.shizuku_selinux
import io.github.samolego.canta.generated.resources.shizuku_terminal_note
import io.github.samolego.canta.ui.dialog.BuiltInShizukuDialog
import io.github.samolego.canta.ui.dialog.openDeveloperOptions
import io.github.samolego.canta.ui.dialog.openUrl
import io.github.samolego.canta.ui.dialog.startNotificationPairing
import io.github.samolego.canta.util.LogUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jetbrains.compose.resources.stringResource
import rikka.shizuku.Shizuku
import rikka.shizuku.embedded.AuthorizedApps
import rikka.shizuku.embedded.EmbeddedShizuku
import rikka.shizuku.embedded.R

private const val TAG = "ShizukuManagerScreen"
private const val GUIDE_URL = "https://shizuku.rikka.app/guide/setup/"
private const val LEARN_URL = "https://shizuku.rikka.app/introduction/"

private enum class Page { HOME, APPS, SETTINGS }

private class ShizukuApp(
    val label: String,
    val packageName: String,
    val uid: Int,
    val icon: ImageBitmap?,
    allowed: Boolean,
) {
    var allowed by mutableStateOf(allowed)
}

private fun Context.plain(id: Int, vararg args: Any): String =
    Html.fromHtml(getString(id, *args), Html.FROM_HTML_MODE_LEGACY).toString().trim()

/** Canta's built-in "Shizuku app", laid out and coloured like the original Shizuku app. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShizukuManagerScreen(onNavigateBack: () -> Unit) {
    ShizukuTheme {
        val context = LocalContext.current
        var page by remember { mutableStateOf(Page.HOME) }
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            when (page) {
                                Page.HOME -> "Shizuku"
                                Page.APPS -> context.getString(R.string.home_app_management_title)
                                Page.SETTINGS -> context.getString(R.string.settings_title)
                            }
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { if (page == Page.HOME) onNavigateBack() else page = Page.HOME }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                        }
                    },
                    actions = {
                        if (page == Page.HOME) {
                            IconButton(onClick = { page = Page.SETTINGS }) {
                                Icon(Icons.Default.Settings, contentDescription = context.getString(R.string.settings_title))
                            }
                        }
                    },
                )
            },
        ) { padding ->
            Surface(modifier = Modifier.padding(padding).fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (page) {
                    Page.HOME -> HomePage(onOpenApps = { page = Page.APPS })
                    Page.APPS -> AppsPage()
                    Page.SETTINGS -> SettingsPage()
                }
            }
        }
    }
}

@Composable
private fun HomeCard(
    icon: ImageVector,
    title: String,
    container: Color = MaterialTheme.colorScheme.surfaceContainer,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(24.dp)
    Surface(
        color = container,
        shape = shape,
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .fillMaxWidth()
            .clip(shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Text(title, style = MaterialTheme.typography.titleMedium)
            }
            content()
        }
    }
}

@Composable
private fun CardText(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.padding(top = 16.dp),
    )
}

@Composable
private fun CardButton(icon: ImageVector, label: String, enabled: Boolean = true, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, enabled = enabled) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(label)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomePage(onOpenApps: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(Shizuku.pingBinder()) }
    var uid by remember { mutableStateOf(-1) }
    var version by remember { mutableStateOf(0) }
    var authorized by remember { mutableStateOf(0) }
    var showManual by remember { mutableStateOf(false) }
    var showCommand by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            running = Shizuku.pingBinder()
            delay(1000)
        }
    }
    LaunchedEffect(running) {
        if (!running) return@LaunchedEffect
        uid = try { Shizuku.getUid() } catch (e: Throwable) { -1 }
        version = try { Shizuku.getVersion() } catch (e: Throwable) { 0 }
        authorized = withContext(Dispatchers.IO) {
            try {
                AuthorizedApps.packages()
                    .filter { it.packageName != context.packageName }
                    .count { AuthorizedApps.granted(it.applicationInfo?.uid ?: -1) }
            } catch (e: Throwable) {
                0
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
        // Server status
        val statusColor = if (running) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer
        HomeCard(
            icon = if (running) Icons.Default.CheckCircle else Icons.Default.Warning,
            title = context.getString(
                if (running) R.string.home_status_service_is_running else R.string.home_status_service_not_running,
                "Shizuku",
            ),
            container = statusColor,
        ) {
            if (running) {
                CardText(context.getString(R.string.home_status_service_version, if (uid == 0) "root" else "adb", version.toString()))
                val selinux = try { Shizuku.getSELinuxContext() } catch (e: Throwable) { null }
                if (selinux != null) {
                    Text(
                        text = stringResource(Res.string.shizuku_selinux, selinux),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                CardButton(Icons.Default.Stop, stringResource(Res.string.builtin_stop)) {
                    try {
                        Shizuku.exit()
                    } catch (e: Throwable) {
                        LogUtils.e(TAG, "Stopping failed", e)
                    }
                    running = false
                }
            }
        }

        // Application management
        HomeCard(
            icon = Icons.Default.Apps,
            title = context.getString(R.string.home_app_management_title),
            onClick = if (running) onOpenApps else null,
        ) {
            CardText(
                if (running) {
                    context.resources.getQuantityString(R.plurals.home_app_management_authorized_apps_count, authorized, authorized)
                } else {
                    context.getString(R.string.home_app_management_empty)
                }
            )
            if (running) {
                Text(
                    context.getString(R.string.home_app_management_view_authorized_apps),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }

        // Terminal (the rish terminal is not part of Canta)
        HomeCard(icon = Icons.Default.Terminal, title = context.getString(R.string.home_terminal_title)) {
            CardText(context.getString(R.string.home_terminal_description))
            Text(
                stringResource(Res.string.shizuku_terminal_note),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 4.dp),
            )
        }

        // Start (root)
        HomeCard(icon = Icons.Default.Security, title = context.getString(R.string.home_root_title)) {
            CardText(context.getString(R.string.settings_start_on_boot_summary))
            Spacer(modifier = Modifier.height(16.dp))
            CardButton(
                icon = if (running) Icons.Default.RestartAlt else Icons.Default.PlayArrow,
                label = context.getString(if (running) R.string.home_root_button_restart else R.string.home_root_button_start),
            ) {
                scope.launch {
                    val output = withContext(Dispatchers.IO) {
                        try {
                            EmbeddedShizuku.startWithRoot(context)
                        } catch (e: Throwable) {
                            LogUtils.e(TAG, "Root start failed", e)
                            "ERROR: $e"
                        }
                    }
                    var waited = 0
                    while (waited < 8000 && !Shizuku.pingBinder()) {
                        delay(500)
                        waited += 500
                    }
                    running = Shizuku.pingBinder()
                    message = if (running) null else output.trim().ifEmpty { "su: no output" }
                }
            }
        }

        // Start via Wireless debugging
        HomeCard(icon = Icons.Default.Adb, title = context.plain(R.string.home_wireless_adb_title)) {
            CardText(
                context.plain(
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) R.string.home_wireless_adb_description
                    else R.string.home_wireless_adb_description_pre_11
                )
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Spacer(modifier = Modifier.height(16.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CardButton(Icons.Default.Settings, stringResource(Res.string.builtin_open_dev_options)) {
                        openDeveloperOptions(context)
                    }
                    CardButton(Icons.Default.PlayArrow, stringResource(Res.string.builtin_pair_notification)) {
                        message = if (startNotificationPairing(context)) {
                            "OK-PAIR"
                        } else {
                            null
                        }
                    }
                    CardButton(Icons.Default.Terminal, stringResource(Res.string.builtin_start)) { showManual = true }
                }
            }
            if (message == "OK-PAIR") {
                Text(
                    stringResource(Res.string.builtin_notification_sent),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 12.dp),
                )
            }
        }

        // Start via a computer
        HomeCard(icon = Icons.Default.Adb, title = context.plain(R.string.home_adb_title)) {
            CardText(context.plain(R.string.home_adb_description, GUIDE_URL))
            Spacer(modifier = Modifier.height(16.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                CardButton(Icons.Default.School, context.getString(R.string.home_adb_button_view_help)) { openUrl(context, GUIDE_URL) }
                CardButton(Icons.Default.Terminal, context.getString(R.string.home_adb_button_view_command)) { showCommand = true }
            }
        }

        // Learn more
        HomeCard(
            icon = Icons.Default.School,
            title = context.getString(R.string.home_learn_more_title),
            onClick = { openUrl(context, LEARN_URL) },
        ) {
            CardText(context.getString(R.string.home_learn_more_description))
        }

        // Log of the last failed start (so the reason can be read and copied).
        var lastLog by remember { mutableStateOf(EmbeddedShizuku.lastLog(context)) }
        if (lastLog.isNotBlank() && !running) {
            HomeCard(icon = Icons.Default.Warning, title = stringResource(Res.string.shizuku_last_log)) {
                SelectionContainer {
                    Text(
                        text = lastLog.trim(),
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(top = 16.dp),
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CardButton(Icons.Default.Terminal, context.getString(R.string.home_adb_dialog_view_command_copy_button)) {
                        context.getSystemService(ClipboardManager::class.java)
                            ?.setPrimaryClip(ClipData.newPlainText("Shizuku log", lastLog))
                    }
                    CardButton(Icons.Default.Stop, "OK") {
                        EmbeddedShizuku.saveLastLog(context, "")
                        lastLog = ""
                    }
                }
            }
        }
        message?.takeIf { it != "OK-PAIR" }?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
            )
        }
        Text(
            "Shizuku (Apache-2.0) / Shizuku-API (MIT) - RikkaApps",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(24.dp),
        )
    }

    if (showManual) {
        BuiltInShizukuDialog(onClose = { showManual = false })
    }
    if (showCommand) {
        val command = "adb shell ${EmbeddedShizuku.starterCommand(context)}"
        AlertDialog(
            onDismissRequest = { showCommand = false },
            title = { Text(context.getString(R.string.home_adb_button_view_command)) },
            text = { Text(command, fontFamily = FontFamily.Monospace) },
            confirmButton = {
                TextButton(onClick = {
                    context.getSystemService(ClipboardManager::class.java)
                        ?.setPrimaryClip(ClipData.newPlainText("Shizuku", command))
                    showCommand = false
                }) { Text(context.getString(R.string.home_adb_dialog_view_command_copy_button)) }
            },
            dismissButton = { TextButton(onClick = { showCommand = false }) { Text("OK") } },
        )
    }
}

@Composable
private fun AppsPage() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<ShizukuApp>?>(null) }
    var running by remember { mutableStateOf(Shizuku.pingBinder()) }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Shizuku.pingBinder()
            if (now != running || (now && apps == null)) {
                running = now
                apps = if (now) withContext(Dispatchers.IO) { loadApps(context) } else null
            }
            delay(1500)
        }
    }

    if (!running) {
        Text(stringResource(Res.string.shizuku_apps_need_service), modifier = Modifier.padding(24.dp))
        return
    }
    val list = apps
    if (list.isNullOrEmpty()) {
        Text(context.getString(R.string.home_app_management_empty), modifier = Modifier.padding(24.dp))
        return
    }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(list, key = { it.packageName + it.uid }) { app ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (app.icon != null) {
                    Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(44.dp))
                } else {
                    Spacer(modifier = Modifier.size(44.dp))
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(app.label, style = MaterialTheme.typography.titleMedium)
                    Text(app.packageName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = app.allowed,
                    onCheckedChange = { allow ->
                        try {
                            if (allow) AuthorizedApps.grant(app.uid) else AuthorizedApps.revoke(app.uid)
                            app.allowed = allow
                        } catch (e: Throwable) {
                            LogUtils.e(TAG, "Updating permission failed", e)
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun SettingsPage() {
    val context = LocalContext.current
    var startOnBoot by remember { mutableStateOf(EmbeddedShizuku.isStartOnBootEnabled(context)) }
    val bootPermission = remember { EmbeddedShizuku.hasSecureSettingsPermission(context) }
    var copied by remember { mutableStateOf(false) }
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Text(context.getString(R.string.settings_startup), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
                Text(stringResource(Res.string.builtin_boot), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(Res.string.builtin_boot_summary), style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = startOnBoot, onCheckedChange = {
                startOnBoot = it
                EmbeddedShizuku.setStartOnBoot(context, it)
            })
        }
        if (startOnBoot && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Text(
                stringResource(if (bootPermission) Res.string.builtin_boot_perm_ok else Res.string.builtin_boot_perm_missing),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 8.dp),
            )
            if (!bootPermission) {
                Spacer(modifier = Modifier.height(8.dp))
                CardButton(Icons.Default.Terminal, stringResource(Res.string.builtin_copy_grant)) {
                    context.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(
                        ClipData.newPlainText(
                            "Canta permission",
                            "adb shell pm grant ${context.packageName} android.permission.WRITE_SECURE_SETTINGS",
                        )
                    )
                    copied = true
                }
                if (copied) Text("OK", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

private fun loadApps(context: Context): List<ShizukuApp> =
    try {
        val packageManager = context.packageManager
        AuthorizedApps.packages()
            .filter { it.packageName != context.packageName }
            .mapNotNull { info ->
                val appInfo = info.applicationInfo ?: return@mapNotNull null
                ShizukuApp(
                    label = appInfo.loadLabel(packageManager).toString(),
                    packageName = info.packageName,
                    uid = appInfo.uid,
                    icon = try { appInfo.loadIcon(packageManager).toImageBitmap() } catch (e: Throwable) { null },
                    allowed = try { AuthorizedApps.granted(appInfo.uid) } catch (e: Throwable) { false },
                )
            }
            .sortedBy { it.label.lowercase() }
    } catch (e: Throwable) {
        LogUtils.e(TAG, "Loading apps failed", e)
        emptyList()
    }

private fun Drawable.toImageBitmap(size: Int = 96): ImageBitmap {
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    setBounds(0, 0, size, size)
    draw(canvas)
    return bitmap.asImageBitmap()
}
