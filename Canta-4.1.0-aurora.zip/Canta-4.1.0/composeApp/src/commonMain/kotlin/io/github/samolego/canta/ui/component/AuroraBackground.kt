package io.github.samolego.canta.ui.component

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

private const val TWO_PI = (2.0 * PI).toFloat()
private const val SEGMENTS = 64

/** One ribbon of light. [speed] must be an Int so the loop is seamless. */
private class Wave(
    val baseY: Float,
    val amplitude: Float,
    val wavelengths: Float,
    val speed: Int,
    val shift: Float,
    val alpha: Float,
    val colorIndex: Int,
)

private val Waves = listOf(
    Wave(baseY = 0.30f, amplitude = 0.050f, wavelengths = 1.1f, speed = 1, shift = 0.0f, alpha = 0.22f, colorIndex = 0),
    Wave(baseY = 0.55f, amplitude = 0.070f, wavelengths = 1.6f, speed = -1, shift = 2.1f, alpha = 0.16f, colorIndex = 1),
    Wave(baseY = 0.78f, amplitude = 0.055f, wavelengths = 0.9f, speed = 2, shift = 4.0f, alpha = 0.20f, colorIndex = 2),
)

/**
 * Slow "light wave" backdrop: a few translucent ribbons drifting sideways,
 * a soft glow that wanders across the screen and a gentle breathing pulse.
 *
 * The animated values are only read while drawing, so nothing recomposes
 * per frame. A full phase takes 60 s, which keeps the motion barely visible.
 * With [animated] = false a still frame is drawn and no animation runs.
 */
@Composable
fun AuroraBackground(
    colors: List<Color>,
    modifier: Modifier = Modifier,
    base: Color = Color.Black,
    intensity: Float = 1f,
    animated: Boolean = true,
) {
    val line = remember { Path() }
    val fill = remember { Path() }

    if (animated) {
        val transition = rememberInfiniteTransition(label = "aurora")
        val phase by transition.animateFloat(
            initialValue = 0f,
            targetValue = TWO_PI,
            animationSpec = infiniteRepeatable(tween(60_000, easing = LinearEasing)),
            label = "phase",
        )
        val breathe by transition.animateFloat(
            initialValue = 0.7f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween(14_000, easing = FastOutSlowInEasing),
                RepeatMode.Reverse,
            ),
            label = "breathe",
        )
        val drift by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween(90_000, easing = FastOutSlowInEasing),
                RepeatMode.Reverse,
            ),
            label = "drift",
        )
        Canvas(modifier.fillMaxSize()) {
            drawAurora(line, fill, colors, base, intensity, phase, breathe, drift)
        }
    } else {
        Canvas(modifier.fillMaxSize()) {
            drawAurora(line, fill, colors, base, intensity, 0.6f, 0.85f, 0.4f)
        }
    }
}

private fun DrawScope.drawAurora(
    line: Path,
    fill: Path,
    colors: List<Color>,
    base: Color,
    intensity: Float,
    phase: Float,
    breathe: Float,
    drift: Float,
) {
    val w = size.width
    val h = size.height
    drawRect(base)
    if (colors.isEmpty() || w <= 0f || h <= 0f) return

    // Wandering glow.
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(colors[0].copy(alpha = 0.16f * breathe * intensity), Color.Transparent),
            center = Offset(w * (0.15f + 0.7f * drift), h * 0.28f),
            radius = w * 0.95f,
        ),
    )

    val strokeWidth = 1.5.dp.toPx()
    for (wave in Waves) {
        val color = colors[wave.colorIndex % colors.size]
        line.rewind()
        fill.rewind()
        for (i in 0..SEGMENTS) {
            val t = i.toFloat() / SEGMENTS
            val x = w * t
            val angle = TWO_PI * wave.wavelengths * t + wave.speed * phase + wave.shift
            val angle2 = TWO_PI * wave.wavelengths * 1.7f * t - wave.speed * phase
            val y = h * (wave.baseY + wave.amplitude * sin(angle) + wave.amplitude * 0.5f * sin(angle2))
            if (i == 0) {
                line.moveTo(x, y)
                fill.moveTo(x, y)
            } else {
                line.lineTo(x, y)
                fill.lineTo(x, y)
            }
        }
        fill.lineTo(w, h)
        fill.lineTo(0f, h)
        fill.close()

        val a = wave.alpha * breathe * intensity
        drawPath(
            path = fill,
            brush = Brush.verticalGradient(
                colors = listOf(color.copy(alpha = a), Color.Transparent),
                startY = h * (wave.baseY - wave.amplitude * 1.5f),
                endY = h * (wave.baseY + 0.32f),
            ),
        )
        drawPath(path = line, color = color.copy(alpha = a * 1.6f), style = Stroke(width = strokeWidth))
    }
}
