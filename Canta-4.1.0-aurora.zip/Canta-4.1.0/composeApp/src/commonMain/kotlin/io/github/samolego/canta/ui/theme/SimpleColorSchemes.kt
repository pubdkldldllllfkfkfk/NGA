package io.github.samolego.canta.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color

private val Neon = Color(0xFF2EEA4A)
private val NeonDim = Color(0xFF1F9E35)
private val NeonDark = Color(0xFF0B2A12)
private val Gray = Color(0xFF9AA39B)

/** Terminal look: black background, neon green accent, monospace text. */
internal val GreenColorScheme = darkColorScheme(
    primary = Neon,
    onPrimary = Color.Black,
    primaryContainer = NeonDark,
    onPrimaryContainer = Neon,
    secondary = Neon,
    onSecondary = Color.Black,
    secondaryContainer = NeonDark,
    onSecondaryContainer = Neon,
    tertiary = NeonDim,
    onTertiary = Color.Black,
    tertiaryContainer = NeonDark,
    onTertiaryContainer = Neon,
    background = Color.Black,
    onBackground = Color(0xFFE6F5E8),
    surface = Color.Black,
    onSurface = Color(0xFFE6F5E8),
    surfaceVariant = Color(0xFF0A120B),
    onSurfaceVariant = Gray,
    surfaceTint = Neon,
    outline = NeonDim,
    outlineVariant = Color(0xFF14541F),
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color(0xFF050A06),
    surfaceContainer = Color(0xFF0A120B),
    surfaceContainerHigh = Color(0xFF0F1A11),
    surfaceContainerHighest = Color(0xFF142016),
)

/** Same terminal look in black and white. */
internal val BlackColorScheme = darkColorScheme(
    primary = Color.White,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF1C1C1C),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFD0D0D0),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF1C1C1C),
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFFBDBDBD),
    onTertiary = Color.Black,
    tertiaryContainer = Color(0xFF1C1C1C),
    onTertiaryContainer = Color.White,
    background = Color.Black,
    onBackground = Color.White,
    surface = Color.Black,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF111111),
    onSurfaceVariant = Color(0xFF9E9E9E),
    surfaceTint = Color.White,
    outline = Color(0xFF8A8A8A),
    outlineVariant = Color(0xFF333333),
    surfaceContainerLowest = Color.Black,
    surfaceContainerLow = Color(0xFF0A0A0A),
    surfaceContainer = Color(0xFF111111),
    surfaceContainerHigh = Color(0xFF181818),
    surfaceContainerHighest = Color(0xFF202020),
)
