package io.github.samolego.canta.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val TerminalShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(4.dp),
    large = RoundedCornerShape(6.dp),
    extraLarge = RoundedCornerShape(8.dp),
)

/**
 * Canta has exactly two looks, both terminal-style: green on black, or
 * white on black. No dynamic/Material You colors; [black] is picked in Settings.
 */
@Composable
fun CantaTheme(
    black: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        // `background` is transparent so the animated backdrop (AuroraBackground,
        // drawn behind the whole UI in CantaApp) shows through every screen.
        // `surface*` stay opaque: dialogs, menus and sheets must remain readable.
        colorScheme = (if (black) BlackColorScheme else GreenColorScheme)
            .copy(background = Color.Transparent),
        typography = Typography,
        shapes = TerminalShapes,
        content = content
    )
}

/** Ribbon colors for the animated backdrop, matching [CantaTheme]. */
fun auroraColors(black: Boolean): List<Color> =
    if (black) {
        listOf(Color(0xFFFFFFFF), Color(0xFFB8C4D0), Color(0xFF8FA0B4))
    } else {
        listOf(Color(0xFF2EEA4A), Color(0xFF14D9B0), Color(0xFF7CFF6B))
    }

/** The black theme gets dimmer ribbons so white-on-black text stays crisp. */
fun auroraIntensity(black: Boolean): Float = if (black) 0.55f else 1f
