package io.github.samolego.canta.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontFamily

private val Mono = FontFamily.Monospace
private val Base = Typography()

/** Every text style in monospace, for the terminal look. */
val Typography = Typography(
    displayLarge = Base.displayLarge.copy(fontFamily = Mono),
    displayMedium = Base.displayMedium.copy(fontFamily = Mono),
    displaySmall = Base.displaySmall.copy(fontFamily = Mono),
    headlineLarge = Base.headlineLarge.copy(fontFamily = Mono),
    headlineMedium = Base.headlineMedium.copy(fontFamily = Mono),
    headlineSmall = Base.headlineSmall.copy(fontFamily = Mono),
    titleLarge = Base.titleLarge.copy(fontFamily = Mono),
    titleMedium = Base.titleMedium.copy(fontFamily = Mono),
    titleSmall = Base.titleSmall.copy(fontFamily = Mono),
    bodyLarge = Base.bodyLarge.copy(fontFamily = Mono),
    bodyMedium = Base.bodyMedium.copy(fontFamily = Mono),
    bodySmall = Base.bodySmall.copy(fontFamily = Mono),
    labelLarge = Base.labelLarge.copy(fontFamily = Mono),
    labelMedium = Base.labelMedium.copy(fontFamily = Mono),
    labelSmall = Base.labelSmall.copy(fontFamily = Mono),
)
