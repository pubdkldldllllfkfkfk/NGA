package rikka.core.ktx

/** Minimal stand-in for rikkax-core's unsafeLazy. */
fun <T> unsafeLazy(initializer: () -> T): Lazy<T> = lazy(LazyThreadSafetyMode.NONE, initializer)
