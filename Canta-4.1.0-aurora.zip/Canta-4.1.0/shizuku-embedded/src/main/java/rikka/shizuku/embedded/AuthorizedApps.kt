package rikka.shizuku.embedded

import android.content.pm.PackageInfo
import android.os.Parcel
import rikka.parcelablelist.ParcelableListSlice
import rikka.shizuku.Shizuku
import rikka.shizuku.server.ServerConstants

/**
 * Lists the apps that use Shizuku and lets them be allowed or denied.
 * Adapted from Shizuku's AuthorizationManager (Apache-2.0), (C) RikkaW.
 */
object AuthorizedApps {
    private const val FLAG_ALLOWED = 1 shl 1
    private const val FLAG_DENIED = 1 shl 2
    private const val MASK_PERMISSION = FLAG_ALLOWED or FLAG_DENIED

    /** Apps (of all users) that ask for Shizuku access. Needs a running server. */
    fun packages(): List<PackageInfo> {
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        return try {
            data.writeInterfaceToken("moe.shizuku.server.IShizukuService")
            data.writeInt(-1)
            Shizuku.getBinder()!!.transact(ServerConstants.BINDER_TRANSACTION_getApplications, data, reply, 0)
            reply.readException()
            @Suppress("UNCHECKED_CAST")
            (ParcelableListSlice.CREATOR.createFromParcel(reply) as ParcelableListSlice<PackageInfo>).list ?: emptyList()
        } finally {
            reply.recycle()
            data.recycle()
        }
    }

    fun granted(uid: Int): Boolean = (Shizuku.getFlagsForUid(uid, MASK_PERMISSION) and FLAG_ALLOWED) == FLAG_ALLOWED

    fun grant(uid: Int) = Shizuku.updateFlagsForUid(uid, MASK_PERMISSION, FLAG_ALLOWED)

    fun revoke(uid: Int) = Shizuku.updateFlagsForUid(uid, MASK_PERMISSION, 0)
}
